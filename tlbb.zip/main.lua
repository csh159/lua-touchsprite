require("UI")
nLog('主线功能'..values.game_main)
require("str")
